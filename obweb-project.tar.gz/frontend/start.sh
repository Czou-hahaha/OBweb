#!/bin/bash
unset HOST
export HOST=localhost
npm start
