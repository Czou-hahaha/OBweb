import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  MagnifyingGlassIcon, 
  MapPinIcon, 
  StarIcon,
  AcademicCapIcon,
  GlobeAltIcon,
  ArrowRightIcon
} from '@heroicons/react/24/outline';

// Import university images
import TsinghuaImage from '../assets/images/universities/tsinghua.svg';
import PekingImage from '../assets/images/universities/peking.svg';
import FudanImage from '../assets/images/universities/fudan.svg';

const Universities: React.FC = () => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('');

  // Placeholder data - will be replaced with real data later
  const universities = [
    {
      id: 1,
      name: 'Tsinghua University',
      chineseName: '清华大学',
      location: 'Beijing',
      ranking: '1',
      description: 'One of the most prestigious universities in China, known for its excellence in science and technology.',
      website: 'https://www.tsinghua.edu.cn',
      image: TsinghuaImage,
      programs: 120,
      students: 50000,
      established: 1911,
      color: 'from-blue-600 to-blue-800'
    },
    {
      id: 2,
      name: 'Peking University',
      chineseName: '北京大学',
      location: 'Beijing',
      ranking: '2',
      description: 'China\'s leading comprehensive university with a rich history and outstanding academic reputation.',
      website: 'https://www.pku.edu.cn',
      image: PekingImage,
      programs: 100,
      students: 45000,
      established: 1898,
      color: 'from-red-600 to-red-800'
    },
    {
      id: 3,
      name: 'Fudan University',
      chineseName: '复旦大学',
      location: 'Shanghai',
      ranking: '3',
      description: 'Top university in Shanghai, renowned for its comprehensive programs and international outlook.',
      website: 'https://www.fudan.edu.cn',
      image: FudanImage,
      programs: 80,
      students: 35000,
      established: 1905,
      color: 'from-green-600 to-green-800'
    }
  ];

  const filteredUniversities = universities.filter(university => 
    university.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    university.chineseName.includes(searchTerm) ||
    university.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const locations = ['All', 'Beijing', 'Shanghai', 'Guangzhou', 'Shenzhen'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="gradient-bg text-white section-padding">
        <div className="container-custom">
          <div className="text-center space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold animate-fade-in">
              {t('universities.title')}
            </h1>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto animate-slide-up">
              {t('universities.subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 bg-white shadow-sm">
        <div className="container-custom">
          <div className="card p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <div className="relative">
                  <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder={t('universities.search')}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="input-field pl-10"
                  />
                </div>
              </div>
              <select 
                value={selectedLocation}
                onChange={(e) => setSelectedLocation(e.target.value)}
                className="input-field"
              >
                <option value="">{t('universities.filter')}</option>
                {locations.map(location => (
                  <option key={location} value={location}>
                    {location === 'All' ? 'All Locations' : location}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Universities Grid */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredUniversities.map((university, index) => (
              <div key={university.id} className="group card overflow-hidden animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                {/* University Image */}
                <div className={`h-48 bg-gradient-to-r ${university.color} flex items-center justify-center relative overflow-hidden`}>
                  <img 
                    src={university.image} 
                    alt={university.name}
                    className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 flex items-center">
                    <StarIcon className="h-4 w-4 text-yellow-500 mr-1" />
                    <span className="text-sm font-bold text-gray-900">#{university.ranking}</span>
                  </div>
                </div>
                
                <div className="p-6 space-y-4">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-1 group-hover:text-primary-600 transition-colors">
                      {university.name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-2">
                      {university.chineseName}
                    </p>
                    <div className="flex items-center text-gray-600 text-sm">
                      <MapPinIcon className="h-4 w-4 mr-2" />
                      <span>{university.location}</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {university.description}
                  </p>

                  {/* University Stats */}
                  <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-100">
                    <div className="text-center">
                      <div className="text-lg font-bold text-primary-600">{university.programs}+</div>
                      <div className="text-xs text-gray-500">Programs</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-primary-600">{university.students.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Students</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-primary-600">{university.established}</div>
                      <div className="text-xs text-gray-500">Established</div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <a
                      href={university.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 btn-secondary text-center text-sm py-2 group-hover:bg-primary-600 group-hover:text-white transition-all duration-200"
                    >
                      <GlobeAltIcon className="h-4 w-4 inline mr-2" />
                      Website
                    </a>
                    <button className="flex-1 btn-primary text-sm py-2 group-hover:bg-primary-700 transition-all duration-200">
                      <AcademicCapIcon className="h-4 w-4 inline mr-2" />
                      Programs
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Load More Button */}
          <div className="text-center mt-12">
            <button className="btn-primary inline-flex items-center group">
              Load More Universities
              <ArrowRightIcon className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Universities;
