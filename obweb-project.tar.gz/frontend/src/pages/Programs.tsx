import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  MagnifyingGlassIcon, 
  AcademicCapIcon, 
  ClockIcon,
  ArrowRightIcon,
  BookOpenIcon,
  CalendarIcon,
  UserGroupIcon
} from '@heroicons/react/24/outline';

const Programs: React.FC = () => {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDegree, setSelectedDegree] = useState('');
  const [selectedField, setSelectedField] = useState('');

  // Placeholder data - will be replaced with real data later
  const programs = [
    {
      id: 1,
      name: 'Computer Science',
      chineseName: '计算机科学',
      university: 'Tsinghua University',
      degree: 'Bachelor',
      duration: '4 years',
      field: 'Engineering',
      description: 'Comprehensive computer science program covering all major areas including AI, machine learning, and software engineering.',
      tuition: '$8,000/year',
      language: 'English/Chinese',
      intake: 'September',
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-800'
    },
    {
      id: 2,
      name: 'Business Administration',
      chineseName: '工商管理',
      university: 'Peking University',
      degree: 'Master',
      duration: '2 years',
      field: 'Business',
      description: 'Advanced business management program for future leaders with focus on international business and innovation.',
      tuition: '$12,000/year',
      language: 'English',
      intake: 'March, September',
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      textColor: 'text-green-800'
    },
    {
      id: 3,
      name: 'International Relations',
      chineseName: '国际关系',
      university: 'Fudan University',
      degree: 'Master',
      duration: '2 years',
      field: 'Social Sciences',
      description: 'Global perspective on international affairs and diplomacy with focus on China\'s role in world politics.',
      tuition: '$10,000/year',
      language: 'English',
      intake: 'September',
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-800'
    }
  ];

  const filteredPrograms = programs.filter(program => 
    program.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    program.chineseName.includes(searchTerm) ||
    program.university.toLowerCase().includes(searchTerm.toLowerCase()) ||
    program.field.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const degrees = ['All', 'Bachelor', 'Master', 'PhD'];
  const fields = ['All', 'Engineering', 'Business', 'Social Sciences', 'Arts', 'Medicine'];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="gradient-bg text-white section-padding">
        <div className="container-custom">
          <div className="text-center space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold animate-fade-in">
              {t('programs.title')}
            </h1>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto animate-slide-up">
              {t('programs.subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Search and Filter */}
      <section className="py-8 bg-white shadow-sm">
        <div className="container-custom">
          <div className="card p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <div className="relative">
                  <MagnifyingGlassIcon className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder={t('programs.search')}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="input-field pl-10"
                  />
                </div>
              </div>
              <select 
                value={selectedDegree}
                onChange={(e) => setSelectedDegree(e.target.value)}
                className="input-field"
              >
                <option value="">{t('programs.filter.degree')}</option>
                {degrees.map(degree => (
                  <option key={degree} value={degree}>
                    {degree === 'All' ? 'All Degrees' : degree}
                  </option>
                ))}
              </select>
              <select 
                value={selectedField}
                onChange={(e) => setSelectedField(e.target.value)}
                className="input-field"
              >
                <option value="">{t('programs.filter.field')}</option>
                {fields.map(field => (
                  <option key={field} value={field}>
                    {field === 'All' ? 'All Fields' : field}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Programs Grid */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
            {filteredPrograms.map((program, index) => (
              <div key={program.id} className="group card overflow-hidden animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                {/* Program Header */}
                <div className={`${program.bgColor} p-6 border-b border-gray-100`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-1 group-hover:text-primary-600 transition-colors">
                        {program.name}
                      </h3>
                      <p className="text-sm text-gray-600 mb-2">
                        {program.chineseName}
                      </p>
                      <p className="text-sm text-primary-600 font-semibold">
                        {program.university}
                      </p>
                    </div>
                    <span className={`${program.textColor} text-xs font-bold px-3 py-1 rounded-full ${program.bgColor} border`}>
                      {program.degree}
                    </span>
                  </div>
                  
                  <div className="flex items-center text-gray-600 text-sm mb-2">
                    <AcademicCapIcon className="h-4 w-4 mr-2" />
                    <span>{program.field}</span>
                  </div>
                  
                  <div className="flex items-center text-gray-600 text-sm">
                    <ClockIcon className="h-4 w-4 mr-2" />
                    <span>{program.duration}</span>
                  </div>
                </div>
                
                <div className="p-6 space-y-4">
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {program.description}
                  </p>

                  {/* Program Details */}
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <BookOpenIcon className="h-4 w-4 mr-2" />
                        <span className="font-medium">Tuition:</span>
                      </div>
                      <div className="text-sm font-semibold text-gray-900">{program.tuition}</div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <CalendarIcon className="h-4 w-4 mr-2" />
                        <span className="font-medium">Intake:</span>
                      </div>
                      <div className="text-sm font-semibold text-gray-900">{program.intake}</div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <UserGroupIcon className="h-4 w-4 mr-2" />
                        <span className="font-medium">Language:</span>
                      </div>
                      <div className="text-sm font-semibold text-gray-900">{program.language}</div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center text-sm text-gray-600">
                        <AcademicCapIcon className="h-4 w-4 mr-2" />
                        <span className="font-medium">Field:</span>
                      </div>
                      <div className="text-sm font-semibold text-gray-900">{program.field}</div>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <button className="flex-1 btn-secondary text-sm py-2 group-hover:bg-primary-600 group-hover:text-white transition-all duration-200">
                      Learn More
                    </button>
                    <button className="flex-1 btn-primary text-sm py-2 group-hover:bg-primary-700 transition-all duration-200">
                      Apply Now
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Load More Button */}
          <div className="text-center mt-12">
            <button className="btn-primary inline-flex items-center group">
              Load More Programs
              <ArrowRightIcon className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Programs;
