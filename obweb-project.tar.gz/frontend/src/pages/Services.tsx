import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  CheckIcon,
  ArrowRightIcon,
  StarIcon,
  ClockIcon,
  UserGroupIcon,
  AcademicCapIcon
} from '@heroicons/react/24/outline';

// Import service images
import ConsultationImage from '../assets/images/services/consultation.svg';
import ProgramsImage from '../assets/images/services/programs.svg';
import PSImage from '../assets/images/services/ps.svg';
import ResumeImage from '../assets/images/services/resume.svg';

const Services: React.FC = () => {
  const { t } = useTranslation();
  const [selectedService, setSelectedService] = useState(0);

  const mainServices = [
    {
      title: 'University Selection Consultation',
      description: 'Comprehensive guidance for choosing the right university and program that matches your academic goals and career aspirations.',
      image: ConsultationImage,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
      services: [
        {
          icon: PSImage,
          title: t('services.ps.title'),
          description: t('services.ps.description'),
          features: [
            'Professional writing service',
            'Multiple revisions included',
            'University-specific customization',
            'Expert review and feedback'
          ],
          price: 'Starting from $300',
          duration: '3-5 days',
          color: 'from-amber-500 to-amber-600'
        },
        {
          icon: ResumeImage,
          title: t('services.resume.title'),
          description: t('services.resume.description'),
          features: [
            'Resume optimization',
            'Format and structure review',
            'Content enhancement',
            'ATS-friendly formatting'
          ],
          price: 'Starting from $100',
          duration: '1-2 days',
          color: 'from-purple-500 to-purple-600'
        }
      ]
    },
    {
      title: 'Program Guidance Services',
      description: 'Expert advice on program selection and career planning to help you make informed decisions about your academic future.',
      image: ProgramsImage,
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600',
      services: [
        {
          icon: ConsultationImage,
          title: t('services.consultation.title'),
          description: t('services.consultation.description'),
          features: [
            'Personalized university recommendations',
            'Admission requirements analysis',
            'Application timeline planning',
            'One-on-one consultation sessions'
          ],
          price: 'Starting from $200',
          duration: '2-3 days',
          color: 'from-blue-500 to-blue-600'
        },
        {
          icon: ProgramsImage,
          title: t('services.programs.title'),
          description: t('services.programs.description'),
          features: [
            'Program comparison and analysis',
            'Career path guidance',
            'Curriculum review',
            'Future prospects evaluation'
          ],
          price: 'Starting from $150',
          duration: '1-2 days',
          color: 'from-green-500 to-green-600'
        }
      ]
    }
  ];

  const processSteps = [
    {
      step: '1',
      title: 'Initial Consultation',
      description: 'We discuss your goals, preferences, and requirements in detail',
      icon: UserGroupIcon,
      color: 'bg-blue-500'
    },
    {
      step: '2',
      title: 'Customized Planning',
      description: 'Create a personalized roadmap for your application journey',
      icon: AcademicCapIcon,
      color: 'bg-green-500'
    },
    {
      step: '3',
      title: 'Execution & Support',
      description: 'Work together to complete your applications with ongoing support',
      icon: ClockIcon,
      color: 'bg-purple-500'
    },
    {
      step: '4',
      title: 'Follow-up & Success',
      description: 'Continue supporting you throughout your academic journey',
      icon: StarIcon,
      color: 'bg-amber-500'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <section className="gradient-bg text-white section-padding">
        <div className="container-custom">
          <div className="text-center space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold animate-fade-in">
              {t('services.title')}
            </h1>
            <p className="text-xl text-primary-100 max-w-3xl mx-auto animate-slide-up">
              {t('services.subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Main Services */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="space-y-16">
            {mainServices.map((mainService, mainIndex) => (
              <div key={mainIndex} className="card p-8 lg:p-12 animate-fade-in" style={{ animationDelay: `${mainIndex * 0.2}s` }}>
                <div className="text-center mb-12">
                  <div className={`w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${mainService.color} flex items-center justify-center`}>
                    <img 
                      src={mainService.image} 
                      alt={mainService.title}
                      className="h-10 w-10 object-contain filter brightness-0 invert"
                    />
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-4">
                    {mainService.title}
                  </h2>
                  <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                    {mainService.description}
                  </p>
                </div>

                {/* Sub-services Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {mainService.services.map((service, serviceIndex) => (
                    <div key={serviceIndex} className={`${mainService.bgColor} rounded-xl p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1`}>
                      <div className="flex items-start mb-6">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${service.color} flex items-center justify-center mr-4 flex-shrink-0`}>
                          <img 
                            src={service.icon} 
                            alt={service.title}
                            className="h-6 w-6 object-contain filter brightness-0 invert"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-xl font-bold text-gray-900 mb-2">
                            {service.title}
                          </h3>
                          <p className="text-gray-600 mb-3">
                            {service.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="text-2xl font-bold text-primary-600">
                              {service.price}
                            </div>
                            <div className="flex items-center text-sm text-gray-500">
                              <ClockIcon className="h-4 w-4 mr-1" />
                              {service.duration}
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="mb-6">
                        <h4 className="text-sm font-semibold text-gray-900 mb-3">What's included:</h4>
                        <ul className="space-y-2">
                          {service.features.map((feature, featureIndex) => (
                            <li key={featureIndex} className="flex items-center text-sm text-gray-600">
                              <CheckIcon className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <button className="w-full btn-primary group">
                        Get Started
                        <ArrowRightIcon className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="section-padding bg-white">
        <div className="container-custom">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Process
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              A proven 4-step process that ensures your success
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <div key={index} className="text-center group animate-fade-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <div className={`w-16 h-16 mx-auto mb-6 rounded-full ${step.color} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <step.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-2xl font-bold text-primary-600 mb-2">Step {step.step}</div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="gradient-bg text-white section-padding">
        <div className="container-custom text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold">
              Ready to Get Started?
            </h2>
            <p className="text-xl text-primary-100">
              Contact us today for a free consultation and take the first step towards your dream education.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="btn-primary inline-flex items-center justify-center group">
                Contact Us Now
                <ArrowRightIcon className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button className="btn-secondary inline-flex items-center justify-center">
                Schedule a Call
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
