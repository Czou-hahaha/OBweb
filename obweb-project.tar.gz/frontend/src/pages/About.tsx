import React from 'react';
import { useTranslation } from 'react-i18next';
import { 
  AcademicCapIcon, 
  CheckCircleIcon, 
  UsersIcon,
  GlobeAltIcon
} from '@heroicons/react/24/outline';

const About: React.FC = () => {
  const { t } = useTranslation();

  const stats = [
    { icon: UsersIcon, number: '100+', label: 'Students Helped' },
    { icon: AcademicCapIcon, number: '50+', label: 'Universities' },
    { icon: GlobeAltIcon, number: '20+', label: 'Countries' },
    { icon: CheckCircleIcon, number: '95%', label: 'Success Rate' }
  ];

  const values = [
    {
      title: 'Personalized Approach',
      description: 'We understand that every student is unique and tailor our services to individual needs and goals.'
    },
    {
      title: 'Expert Knowledge',
      description: 'Our team has deep understanding of Chinese higher education system and admission processes.'
    },
    {
      title: 'Proven Results',
      description: 'We have helped hundreds of students successfully gain admission to their dream universities.'
    },
    {
      title: 'Ongoing Support',
      description: 'We provide continuous support throughout your entire study abroad journey.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary-600 to-primary-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {t('about.title')}
            </h1>
            <p className="text-xl md:text-2xl text-primary-100 max-w-3xl mx-auto">
              {t('about.subtitle')}
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Our Mission
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              {t('about.description')}
            </p>
            <p className="text-lg text-gray-600">
              We believe that studying in China offers incredible opportunities for personal and professional growth. 
              Our mission is to make this journey accessible and successful for students from around the world.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="bg-primary-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="h-8 w-8 text-primary-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our Values
            </h2>
            <p className="text-xl text-gray-600">
              What drives us to provide exceptional service
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  {value.title}
                </h3>
                <p className="text-gray-600">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Meet Our Team
            </h2>
            <p className="text-xl text-gray-600">
              Experienced professionals dedicated to your success
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-xl shadow-sm p-8 text-center">
              <div className="w-32 h-32 bg-primary-100 rounded-full mx-auto mb-6 flex items-center justify-center">
                <span className="text-4xl font-bold text-primary-600">OB</span>
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">
                Our Expert Team
              </h3>
              <p className="text-gray-600 mb-4">
                With years of experience in Chinese higher education and international student services, 
                our team is committed to helping you achieve your academic goals.
              </p>
              <div className="text-sm text-gray-500">
                Education Consultant • Study Abroad Expert • Application Specialist
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-primary-100 mb-8">
            Let us help you achieve your academic dreams in China
          </p>
          <button className="bg-white text-primary-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
            Get Started Today
          </button>
        </div>
      </section>
    </div>
  );
};

export default About;
