import React from 'react';
import { Link } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { 
  AcademicCapIcon,
  EnvelopeIcon,
  PhoneIcon,
  MapPinIcon,
  GlobeAltIcon
} from '@heroicons/react/24/outline';

const Footer: React.FC = () => {
  const { t } = useTranslation();

  const footerLinks = {
    company: [
      { name: t('nav.about'), href: '/about' },
      { name: t('nav.services'), href: '/services' },
      { name: 'Careers', href: '#' },
      { name: 'Blog', href: '#' },
    ],
    resources: [
      { name: t('nav.universities'), href: '/universities' },
      { name: t('nav.programs'), href: '/programs' },
      { name: 'Admission Guide', href: '#' },
      { name: 'Scholarships', href: '#' },
    ],
    support: [
      { name: t('nav.contact'), href: '/contact' },
      { name: 'FAQ', href: '#' },
      { name: 'Help Center', href: '#' },
      { name: 'Privacy Policy', href: '#' },
    ],
  };

  const socialLinks = [
    { name: 'WeChat', href: '#', icon: '💬' },
    { name: 'Weibo', href: '#', icon: '📱' },
    { name: 'QQ', href: '#', icon: '💻' },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container-custom section-padding">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-r from-primary-600 to-primary-800 rounded-lg flex items-center justify-center">
                <AcademicCapIcon className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold">OBtest</h3>
                <p className="text-sm text-gray-400">Study in China</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-relaxed mb-6">
              Your trusted partner for studying in China. We provide comprehensive guidance and support for international students.
            </p>
            <div className="space-y-3">
              <div className="flex items-center text-sm text-gray-400">
                <EnvelopeIcon className="h-4 w-4 mr-3" />
                <span>info@obtest.com</span>
              </div>
              <div className="flex items-center text-sm text-gray-400">
                <PhoneIcon className="h-4 w-4 mr-3" />
                <span>+86 138 0000 0000</span>
              </div>
              <div className="flex items-center text-sm text-gray-400">
                <MapPinIcon className="h-4 w-4 mr-3" />
                <span>Beijing, China</span>
              </div>
            </div>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-400 hover:text-white transition-colors duration-200 text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Resources</h4>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-400 hover:text-white transition-colors duration-200 text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Support</h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-400 hover:text-white transition-colors duration-200 text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">
              © 2024 OBtest. All rights reserved.
            </div>
            
            <div className="flex items-center space-x-6">
              {/* Social Links */}
              <div className="flex items-center space-x-4">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.href}
                    className="text-gray-400 hover:text-white transition-colors duration-200 text-lg"
                    title={social.name}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
              
              {/* Language Switcher */}
              <div className="flex items-center text-sm text-gray-400">
                <GlobeAltIcon className="h-4 w-4 mr-2" />
                <span>English / 中文</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
